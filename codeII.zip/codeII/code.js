//DECLARACOES DE VARIAVEIS
var canvas, ctx, flag = false,
    prevX = 0,
    currX = 0,
    prevY = 0,
    currY = 0,
    dot_flag = false;

var saved = true;

var x = '#3498DB',
    y = 4;

var eyeT = true,
    groupT = true;

// FUNCAO DE INICIALIZACAO DE CANVAS
function init() {
    canvas = document.getElementById('canvas');
    var image = document.getElementById('main-image');
    canvas.width = image.width;
    canvas.height = image.height;
    ctx = canvas.getContext("2d");
    w = canvas.width;
    h = canvas.height;
}

// FUNCOES DE DESENHO
function mousemoveF (e) {
  findxy('move', e);
}

function mousedownF (e) {
  findxy('down', e);
}

function mouseupF (e) {
  findxy('up', e);
}

function mouseoutF (e) {
  findxy('out', e);
}

function initDrawing () {
  canvas.addEventListener("mousemove", mousemoveF, false);
  canvas.addEventListener("mousedown", mousedownF, false);
  canvas.addEventListener("mouseup", mouseupF, false);
  canvas.addEventListener("mouseout", mouseoutF, false);
}

function stopDrawing (){
  canvas.removeEventListener("mousemove", mousemoveF, false);
  canvas.removeEventListener("mousedown", mousedownF, false);
  canvas.removeEventListener("mouseup", mouseupF, false);
  canvas.removeEventListener("mouseout", mouseoutF, false);
}

function findxy(res, e) {
    if (res == 'down') {
        prevX = currX;
        prevY = currY;
        currX = e.clientX - canvas.offsetLeft;
        currY = e.clientY - canvas.offsetTop;

        flag = true;
        dot_flag = true;
        if (dot_flag) {
            ctx.beginPath();
            ctx.fillStyle = x;
            ctx.fillRect(currX, currY, 2, 2);
            ctx.closePath();
            dot_flag = false;
        }
    }
    if (res == 'up' || res == "out") {
        flag = false;
    }
    if (res == 'move') {
        if (flag) {
            prevX = currX;
            prevY = currY;
            currX = e.clientX - canvas.offsetLeft;
            currY = e.clientY - canvas.offsetTop;
            draw();
        }
    }
}

// funcao para resetar qual botão de cor esta selecionado
function clearColorSelected () {
  var picker;
  picker = document.getElementById('blue');
  picker.classList.remove('color-selected');
  picker = document.getElementById('red');
  picker.classList.remove('color-selected');
  picker = document.getElementById('green');
  picker.classList.remove('color-selected');
  picker = document.getElementById('yellow');
  picker.classList.remove('color-selected');
  picker = document.getElementById('purple');
  picker.classList.remove('color-selected');
  picker = document.getElementById('dark');
  picker.classList.remove('color-selected');
  picker = document.getElementById('white');
  picker.classList.remove('color-selected');
}

// funcao para definir cor de desenho
function color(obj) {
    clearColorSelected();
    switch (obj.id) {
        case "blue":
            x = '#3498DB';
            obj.className = "color-picker color-blue color-selected";
            break;
        case "red":
            x = '#E74C3C';
            obj.className = "color-picker color-red color-selected";
            break;
        case "dark":
            x = '#2C3E50';
            obj.className = "color-picker color-dark color-selected";
            break;
        case "yellow":
            x = "#F1C40F";
            obj.className = "color-picker color-yellow color-selected";
            break;
        case "green":
            x = '#2ECC71';
            obj.className = "color-picker color-green color-selected";
            break;
        case "purple":
            x = '#9B59B6';
            obj.className = "color-picker color-purple color-selected";
            break;
        case "white":
            x = "white";
            obj.className = "color-picker color-white color-selected";
            break;
    }
    y = 4;
}

// funcao de desenho
function draw() {
    saved = false;
    ctx.beginPath();
    ctx.moveTo(prevX, prevY);
    ctx.lineTo(currX, currY);
    ctx.strokeStyle = x;
    ctx.lineWidth = y;
    ctx.stroke();
    ctx.closePath();
}

// funcao para apagar canvas
function erase() {
  ctx.clearRect(0, 0, w, h);
  saved = true;
}

// funcao para salvar desenho
function save() {
    var groupdiv = document.getElementById("my-group-div");
    var newimg = document.createElement("IMG");
    newimg.className = "canvas-pos";
    var dataURL = canvas.toDataURL();
    newimg.src = dataURL;
    groupdiv.appendChild(newimg);
    erase();
    visualization();
}

// toque no x: apaga canvas e fecha modo de edicao
function closeEditing() {
  if (saved) erase();
  else {
    var m = confirm ("Apagar as mudanças suas mudanças na obra e voltar")
    if (m) {
        erase();
        // voltar para estado sem edição
    }
  }
}

// entrar no modo de visualização
function visualization () {
  var editbtn = document.getElementById('editbtn');
  editbtn.style.display = null;
  var savebtn = document.getElementById('savebtn');
  savebtn.style.display = "none";
  var edit = document.getElementById('all-edit-tools');
  edit.style.display = "none";
  var edit = document.getElementById('visual-tools');
  edit.style.display = null;
  notDrawBtn();
}

// entrar no modo de edicao
function edit (obj) {
  obj.style.display = "none";
  var savebtn = document.getElementById('savebtn');
  savebtn.style.display = null;
  var edit = document.getElementById('all-edit-tools');
  edit.style.display = null;
  var edit = document.getElementById('visual-tools');
  edit.style.display = "none";
}

// entrar no modo de desenho
function drawBtn () {
  var picker = document.getElementById('picker');
  picker.style.display = null;
  var editTools = document.getElementById('edit-tools');
  editTools.style.display = "none";

  initDrawing();
}

// sair do modo de desenho
function notDrawBtn() {
  var picker = document.getElementById('picker');
  picker.style.display = "none";
  var editTools = document.getElementById('edit-tools');
  editTools.style.display = null;

  stopDrawing();
}

// toogle de visualizacao das edicoes de todos
// function toogleEyeBtn (obj) {
//   var alldiv = document.getElementById("all-div");
//   if (eyeT) {
//     eyeT = false;
//     obj.className = "not-eye-btn";
//     alldiv.style.display = "none";
//   }
//   else {
//     eyeT = true;
//     obj.className = "eye-btn";
//     alldiv.style.display = null;
//   }
// }

// toogle de visualizacao das edicoes do seu grupo
function toogleGroupBtn(obj) {
  var alldiv = document.getElementById("my-group-div");
  if (groupT) {
    groupT = false;
    obj.className = "not-group-btn";
    alldiv.style.display = "none";
  }
  else {
    groupT = true;
    obj.className = "group-btn";
    alldiv.style.display = "block";
  }
}
